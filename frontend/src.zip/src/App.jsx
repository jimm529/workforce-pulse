import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import "./App.css";

const COLORS = [
  "#4F46E5",
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#06B6D4",
  "#8B5CF6",
  "#EC4899",
  "#84CC16",
];

export default function App() {
  const [data, setData] = useState(null);
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const downloadPDF = async () => {
  const input = document.body;

  const canvas = await html2canvas(input);

  const imgData = canvas.toDataURL("image/png");

  const pdf = new jsPDF("p", "mm", "a4");

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight =
    (canvas.height * pdfWidth) / canvas.width;

  pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);

  pdf.save("WorkforcePulseDashboard.pdf");
};
  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/dashboard")
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, []);

  if (!data) {
    return <h2 style={{ textAlign: "center" }}>Loading Workforce Pulse...</h2>;
  }

  const departmentData = Object.entries(data.department).map(([name, value]) => ({
    name,
    value,
  }));

  const applicationData = Object.entries(data.applications).map(([name, value]) => ({
    name,
    value,
  }));

  const filteredRecords =
    departmentFilter === "All"
      ? data.records
      : data.records.filter((r) => r.department === departmentFilter);

  return (
    <div className="container">
      <h1>🚀 Workforce Pulse Dashboard</h1>
      <button
  onClick={downloadPDF}
  style={{
    padding: "10px 20px",
    marginBottom: "20px",
    background: "#4F46E5",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer"
  }}
>
  Export Dashboard PDF
</button>
      <div className="cards">
  <div className="card">
    <h3>Total Activities</h3>
    <h2>{data.summary.activities}</h2>
  </div>

  <div className="card">
    <h3>Total Minutes</h3>
    <h2>{Math.round(data.summary.total_minutes)}</h2>
  </div>

  <div className="card">
    <h3>Recoverable Hours</h3>
    <h2>{data.summary.recoverable_hours}</h2>
  </div>

  <div className="card">
    <h3>Recoverable Cost</h3>
    <h2>₹ {Math.round(data.summary.recoverable_cost)}</h2>
  </div>
</div>
<div
  className="card"
  style={{ marginTop: "20px", marginBottom: "20px" }}
>
  <h2>🤖 AI Insights</h2>

  <p
    style={{
      fontSize: "16px",
      lineHeight: "28px"
    }}
  >
    {data.ai_summary}
  </p>
</div>

<div style={{ marginBottom: 20 }}> <div className="grid">

  <div className="chart">

    <h2>Department Usage</h2>

    <ResponsiveContainer width="100%" height={320}>

      <BarChart data={departmentData}>

        <CartesianGrid strokeDasharray="3 3" />

        <XAxis dataKey="name" />

        <YAxis />

        <Tooltip />

        <Bar dataKey="value">

          {departmentData.map((_, i) => (
            <Cell
              key={i}
              fill={COLORS[i % COLORS.length]}
            />
          ))}

        </Bar>

      </BarChart>

    </ResponsiveContainer>

  </div>

  <div className="chart">

    <h2>Application Usage</h2>

    <ResponsiveContainer width="100%" height={320}>

      <PieChart>

        <Pie
          data={applicationData}
          dataKey="value"
          nameKey="name"
          outerRadius={110}
          label
        >

          {applicationData.map((_, i) => (
            <Cell
              key={i}
              fill={COLORS[i % COLORS.length]}
            />
          ))}

        </Pie>

        <Tooltip />

      </PieChart>

    </ResponsiveContainer>

  </div>

</div>
 <h2>Employee Activity</h2>

<table>

  <thead>

    <tr>

      <th>ID</th>
      <th>Name</th>
      <th>Department</th>
      <th>Task</th>
      <th>Application</th>
      <th>Duration</th>

    </tr>

  </thead>

  <tbody>

    {filteredRecords.map((r, i) => (

      <tr key={i}>

        <td>{r.employee_id}</td>

        <td>{r.name || "-"}</td>

        <td>{r.department || "-"}</td>

        <td>{r.task_category}</td>

        <td>{r.app_used}</td>

        <td>{r.duration_minutes} min</td>

      </tr>

    ))}

  </tbody>

</table>
 <h2>Top Automation Opportunities</h2>

<table>

  <thead>

    <tr>

      <th>Employee</th>

      <th>Task</th>

      <th>Application</th>

      <th>Priority Score</th>

    </tr>

  </thead>

  <tbody>

    {data.automation_priority.map((item, index) => (

      <tr key={index}>

        <td>{item.employee}</td>

        <td>{item.task}</td>

        <td>{item.application}</td>

        <td>{item.score}</td>

      </tr>

    ))}

  </tbody>

</table>
    </div>
  );
}